Spot ESP - Arduino Setup Instructions
=====================================

1. Requirements:
   - Arduino IDE (1.8.x or 2.x) installed
   - ESP32 board support installed:
     -> In Arduino IDE: File > Preferences > Additional Board URLs:
        https://raw.githubusercontent.com/espressif/arduino-esp32/gh-pages/package_esp32_index.json
     -> Then go to Tools > Board > Boards Manager, and install "esp32" by Espressif

2. Required Libraries (install via Library Manager):
   - TFT_eSPI by Bodmer
   - XPT2046_Touchscreen by Paul Stoffregen
   - SD (built-in with Arduino-ESP32)
   - ArduinoOTA (built-in with Arduino-ESP32)

3. Board Selection:
   - Tools > Board: "ESP32 Dev Module" or "ESP32 Wrover Module"
   - Flash Frequency: 80MHz
   - Flash Mode: QIO
   - Partition Scheme: Default 4MB with spiffs
   - Upload Speed: 921600

4. TFT_eSPI Configuration:
   - Edit `User_Setup.h` inside TFT_eSPI library folder to match ESP32-2432S028 pinout:
     (or copy a matching setup file like `Setup25_TTGO_T_Display.h`)

5. Uploading:
   - Open Spot_ESP.ino in Arduino IDE
   - Connect ESP32 via USB
   - Select correct COM port and board
   - Click Upload

6. Web Flasher (Optional):
   - Use https://esphome.github.io/esp-web-tools/ or similar
   - Convert this sketch to a .bin file (Sketch > Export compiled binary)
   - Upload via ESP Web Tools

Enjoy using Spot ESP!

