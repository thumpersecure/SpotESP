Spot ESP - Arduino Project
==========================

Use this project with the Arduino IDE or Arduino CLI to build firmware for ESP32-2432S028 (CYD).

1. Required Libraries:
   - TFT_eSPI
   - XPT2046_Touchscreen
   - SD
   - ArduinoOTA
   (Install via Library Manager)

2. Board:
   - ESP32 Dev Module or ESP32 Wrover Module

3. To Compile:
   - Open Spot_ESP.ino in Arduino IDE
   - Or use:
     arduino-cli compile --fqbn esp32:esp32:esp32wrover Spot_ESP

4. To Upload:
   - arduino-cli upload -p /dev/ttyUSB0 --fqbn esp32:esp32:esp32wrover Spot_ESP

Enjoy Spot ESP!
